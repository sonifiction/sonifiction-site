autowatch = 1;

var myDict = new Dict("weather");
//based on a number of the default max js/dict patches, the following parses the dictionary from a string to a json
//then queries the json dictionary for the 
function parseDict()
{   
    var dataToString = myDict.get("body");

    var parsedDict = new Dict("parsedDict");

    parsedDict.parse(dataToString);
    var statsList = [];
    tempKelvin = parsedDict.get("main::temp");
    tempCelcius = tempKelvin - 273.15;
    statsList.push(tempCelcius);
    statsList.push(parsedDict.get("main::humidity"));
    statsList.push(parsedDict.get("main::pressure"));
    statsList.push(parsedDict.get("wind::speed"));
    outlet(0, statsList);
}

//output list with temperature, humidity, pressure, and wind speed